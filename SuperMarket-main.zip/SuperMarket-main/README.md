# Micro-Market API

API REST simple para la gestión de un mini market con Spring Boot 3, Java 17 y MySQL.

## Qué incluye
- CRUD de categorías
- CRUD de productos con borrado lógico
- CRUD de proveedores
- CRUD de empleados
- Entrada de almacén para aumentar stock y asociar proveedor
- Registro de ventas con descuento automático de stock
- Consulta de ventas
- Validaciones con DTOs y manejo global de excepciones

## Reglas de negocio cubiertas
- Los productos no se eliminan físicamente, se desactivan.
- El código de barras del producto es único.
- El NIT del proveedor es obligatorio y único.
- Al consultar una categoría se incluyen sus productos.
- Un producto puede tener varios proveedores y un proveedor varios productos.
- La entrada de almacén suma stock al producto.
- Los cargos permitidos son: `ADMINISTRADOR`, `CAJERO` y `AUXILIAR`.
- Se puede consultar empleados por cargo o por rango de fecha de ingreso.
- Una venta siempre queda asociada a un empleado.
- Si no hay stock suficiente, la venta falla con `400 Bad Request` y no se confirma.
- La venta calcula automáticamente subtotal, IVA (19%) y total.

## Cómo ejecutar
Configura MySQL y luego ejecuta desde la raíz del proyecto:

```powershell
.\mvnw.cmd spring-boot:run
```

## Configuración por defecto
- Puerto: `8080`
- Base de datos: `micro_market`
- Usuario MySQL: `root`
- Password MySQL: vacía

Puedes cambiarlo por variables de entorno:
- `DB_HOST`
- `DB_PORT`
- `DB_NAME`
- `DB_USERNAME`
- `DB_PASSWORD`

## Endpoints principales
- `GET/POST/PUT/DELETE /api/v1/categorias`
- `GET/POST/PUT/DELETE /api/v1/productos`
- `PATCH /api/v1/productos/{id}/estado?activo=true|false`
- `GET/POST/PUT/DELETE /api/v1/proveedores`
- `GET/POST/PUT/DELETE /api/v1/empleados`
- `GET /api/v1/empleados/filtros`
- `POST /api/v1/abastecimiento/entrada-almacen`
- `POST /api/v1/ventas`
- `GET /api/v1/ventas`
- `GET /api/v1/ventas/{id}`

## Datos iniciales
El proyecto trae `src/main/resources/data.sql` con datos de ejemplo para categorías, productos, proveedores y empleados.
