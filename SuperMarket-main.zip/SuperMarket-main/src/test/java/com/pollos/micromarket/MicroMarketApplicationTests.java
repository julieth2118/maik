package com.pollos.micromarket;

import org.junit.jupiter.api.Test;

class MicroMarketApplicationTests {

    @Test
    void contextLoads() {
    }
}
