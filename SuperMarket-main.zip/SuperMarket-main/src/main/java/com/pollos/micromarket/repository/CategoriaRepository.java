package com.pollos.micromarket.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;

import com.pollos.micromarket.entity.Categoria;

public interface CategoriaRepository extends JpaRepository<Categoria, Long> {

    boolean existsByNombreIgnoreCase(String nombre);

    boolean existsByNombreIgnoreCaseAndIdNot(String nombre, Long id);

    @Override
    @EntityGraph(attributePaths = {"productos"})
    List<Categoria> findAll();

    @Override
    @EntityGraph(attributePaths = {"productos"})
    Optional<Categoria> findById(Long id);
}
