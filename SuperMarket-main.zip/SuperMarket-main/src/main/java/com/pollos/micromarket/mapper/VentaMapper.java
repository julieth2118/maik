package com.pollos.micromarket.mapper;

import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

import com.pollos.micromarket.dto.response.DetalleVentaResponseDTO;
import com.pollos.micromarket.dto.response.VentaResponseDTO;
import com.pollos.micromarket.entity.DetalleVenta;
import com.pollos.micromarket.entity.Venta;

@Component
public class VentaMapper {

    public VentaResponseDTO toResponse(Venta venta) {
        VentaResponseDTO dto = new VentaResponseDTO();
        dto.setId(venta.getId());
        dto.setFechaVenta(venta.getFechaVenta());
        dto.setEmpleadoId(venta.getEmpleado().getId());
        dto.setEmpleadoNombre(venta.getEmpleado().getNombre());
        dto.setSubtotal(venta.getSubtotal());
        dto.setIva(venta.getIva());
        dto.setTotal(venta.getTotal());
        dto.setDetalles(venta.getDetalles().stream()
                .map(this::toDetalleResponse)
                .collect(Collectors.toList()));
        return dto;
    }

    private DetalleVentaResponseDTO toDetalleResponse(DetalleVenta detalle) {
        DetalleVentaResponseDTO dto = new DetalleVentaResponseDTO();
        dto.setId(detalle.getId());
        dto.setProductoId(detalle.getProducto().getId());
        dto.setProductoNombre(detalle.getProducto().getNombre());
        dto.setCantidad(detalle.getCantidad());
        dto.setPrecioUnitario(detalle.getPrecioUnitario());
        dto.setSubtotalLinea(detalle.getSubtotalLinea());
        return dto;
    }
}
