package com.pollos.micromarket.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;

import com.pollos.micromarket.entity.Proveedor;

public interface ProveedorRepository extends JpaRepository<Proveedor, Long> {

    boolean existsByNit(String nit);

    boolean existsByNitAndIdNot(String nit, Long id);

    @Override
    @EntityGraph(attributePaths = {"productos"})
    List<Proveedor> findAll();

    @Override
    @EntityGraph(attributePaths = {"productos"})
    Optional<Proveedor> findById(Long id);
}
