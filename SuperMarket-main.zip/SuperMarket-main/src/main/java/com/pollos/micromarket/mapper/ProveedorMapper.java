package com.pollos.micromarket.mapper;

import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

import com.pollos.micromarket.dto.response.ProductoSimpleResponseDTO;
import com.pollos.micromarket.dto.response.ProveedorResponseDTO;
import com.pollos.micromarket.entity.Producto;
import com.pollos.micromarket.entity.Proveedor;

@Component
public class ProveedorMapper {

    public ProveedorResponseDTO toResponse(Proveedor proveedor) {
        ProveedorResponseDTO dto = new ProveedorResponseDTO();
        dto.setId(proveedor.getId());
        dto.setNombre(proveedor.getNombre());
        dto.setNit(proveedor.getNit());
        dto.setTelefono(proveedor.getTelefono());
        dto.setCorreo(proveedor.getCorreo());
        dto.setDireccion(proveedor.getDireccion());
        dto.setProductos(proveedor.getProductos().stream()
                .map(this::toProductoSimple)
                .collect(Collectors.toList()));
        return dto;
    }

    private ProductoSimpleResponseDTO toProductoSimple(Producto producto) {
        ProductoSimpleResponseDTO dto = new ProductoSimpleResponseDTO();
        dto.setId(producto.getId());
        dto.setNombre(producto.getNombre());
        dto.setCodigoBarras(producto.getCodigoBarras());
        dto.setPrecioVenta(producto.getPrecioVenta());
        dto.setStock(producto.getStock());
        dto.setActivo(producto.getActivo());
        return dto;
    }
}
