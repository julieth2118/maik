package com.pollos.micromarket.mapper;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

import com.pollos.micromarket.dto.response.ProductoResponseDTO;
import com.pollos.micromarket.dto.response.ProveedorSimpleResponseDTO;
import com.pollos.micromarket.entity.Producto;
import com.pollos.micromarket.entity.Proveedor;

@Component
public class ProductoMapper {

    public ProductoResponseDTO toResponse(Producto producto) {
        ProductoResponseDTO dto = new ProductoResponseDTO();
        dto.setId(producto.getId());
        dto.setNombre(producto.getNombre());
        dto.setDescripcion(producto.getDescripcion());
        dto.setCodigoBarras(producto.getCodigoBarras());
        dto.setPrecioCompra(producto.getPrecioCompra());
        dto.setPrecioVenta(producto.getPrecioVenta());
        dto.setStock(producto.getStock());
        dto.setActivo(producto.getActivo());
        dto.setCategoriaId(producto.getCategoria().getId());
        dto.setCategoriaNombre(producto.getCategoria().getNombre());
        dto.setProveedores(producto.getProveedores().stream()
                .map(this::toProveedorSimple)
                .collect(Collectors.toList()));
        return dto;
    }

    private ProveedorSimpleResponseDTO toProveedorSimple(Proveedor proveedor) {
        ProveedorSimpleResponseDTO dto = new ProveedorSimpleResponseDTO();
        dto.setId(proveedor.getId());
        dto.setNombre(proveedor.getNombre());
        dto.setNit(proveedor.getNit());
        return dto;
    }

    public List<ProductoResponseDTO> toResponseList(List<Producto> productos) {
        return productos.stream().map(this::toResponse).collect(Collectors.toList());
    }
}
