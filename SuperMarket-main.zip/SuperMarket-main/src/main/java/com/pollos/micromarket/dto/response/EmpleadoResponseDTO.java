package com.pollos.micromarket.dto.response;

import java.math.BigDecimal;
import java.time.LocalDate;

import com.pollos.micromarket.enums.CargoEmpleado;

import lombok.Data;

@Data
public class EmpleadoResponseDTO {
    private Long id;
    private String cedula;
    private String nombre;
    private CargoEmpleado cargo;
    private LocalDate fechaIngreso;
    private BigDecimal salario;
}
