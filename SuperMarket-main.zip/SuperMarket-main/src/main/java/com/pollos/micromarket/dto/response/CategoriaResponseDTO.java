package com.pollos.micromarket.dto.response;

import java.util.List;

import lombok.Data;

@Data
public class CategoriaResponseDTO {
    private Long id;
    private String nombre;
    private String descripcion;
    private List<ProductoSimpleResponseDTO> productos;
}
