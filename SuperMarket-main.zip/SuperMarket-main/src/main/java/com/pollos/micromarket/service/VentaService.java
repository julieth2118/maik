package com.pollos.micromarket.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.pollos.micromarket.dto.request.DetalleVentaRequestDTO;
import com.pollos.micromarket.dto.request.VentaRequestDTO;
import com.pollos.micromarket.dto.response.VentaResponseDTO;
import com.pollos.micromarket.entity.DetalleVenta;
import com.pollos.micromarket.entity.Empleado;
import com.pollos.micromarket.entity.Producto;
import com.pollos.micromarket.entity.Venta;
import com.pollos.micromarket.exception.BusinessRuleException;
import com.pollos.micromarket.exception.InsufficientStockException;
import com.pollos.micromarket.exception.ResourceNotFoundException;
import com.pollos.micromarket.mapper.VentaMapper;
import com.pollos.micromarket.repository.EmpleadoRepository;
import com.pollos.micromarket.repository.ProductoRepository;
import com.pollos.micromarket.repository.VentaRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class VentaService {

    private static final BigDecimal IVA_RATE = new BigDecimal("0.19");

    private final VentaRepository ventaRepository;
    private final ProductoRepository productoRepository;
    private final EmpleadoRepository empleadoRepository;
    private final VentaMapper ventaMapper;

    @Transactional
    public VentaResponseDTO procesarVenta(VentaRequestDTO request) {
        Empleado empleado = empleadoRepository.findById(request.getEmpleadoId())
                .orElseThrow(() -> new ResourceNotFoundException("Empleado no encontrado con id: " + request.getEmpleadoId()));

        Venta venta = new Venta();
        venta.setFechaVenta(LocalDateTime.now());
        venta.setEmpleado(empleado);

        BigDecimal subtotal = BigDecimal.ZERO;

        for (DetalleVentaRequestDTO detalleRequest : request.getDetalles()) {
            Producto producto = productoRepository.findById(detalleRequest.getProductoId())
                    .orElseThrow(() -> new ResourceNotFoundException("Producto no encontrado con id: " + detalleRequest.getProductoId()));

            if (!Boolean.TRUE.equals(producto.getActivo())) {
                throw new BusinessRuleException("El producto " + producto.getNombre() + " está inactivo y no puede venderse");
            }

            if (producto.getStock() < detalleRequest.getCantidad()) {
                throw new InsufficientStockException("Stock insuficiente para el producto: " + producto.getNombre());
            }

            producto.setStock(producto.getStock() - detalleRequest.getCantidad());
            productoRepository.save(producto);

            BigDecimal subtotalLinea = producto.getPrecioVenta()
                    .multiply(BigDecimal.valueOf(detalleRequest.getCantidad()))
                    .setScale(2, RoundingMode.HALF_UP);

            DetalleVenta detalle = new DetalleVenta();
            detalle.setVenta(venta);
            detalle.setProducto(producto);
            detalle.setCantidad(detalleRequest.getCantidad());
            detalle.setPrecioUnitario(producto.getPrecioVenta());
            detalle.setSubtotalLinea(subtotalLinea);

            venta.getDetalles().add(detalle);
            subtotal = subtotal.add(subtotalLinea);
        }

        BigDecimal subtotalEscala = subtotal.setScale(2, RoundingMode.HALF_UP);
        BigDecimal iva = subtotalEscala.multiply(IVA_RATE).setScale(2, RoundingMode.HALF_UP);
        BigDecimal total = subtotalEscala.add(iva).setScale(2, RoundingMode.HALF_UP);

        venta.setSubtotal(subtotalEscala);
        venta.setIva(iva);
        venta.setTotal(total);

        Venta saved = ventaRepository.save(venta);
        return findById(saved.getId());
    }

    @Transactional(readOnly = true)
    public List<VentaResponseDTO> findAll() {
        return ventaRepository.findAllByOrderByFechaVentaDesc().stream()
                .map(ventaMapper::toResponse)
                .toList();
    }

    @Transactional(readOnly = true)
    public VentaResponseDTO findById(Long id) {
        Venta venta = ventaRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Venta no encontrada con id: " + id));
        return ventaMapper.toResponse(venta);
    }
}
