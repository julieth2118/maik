package com.pollos.micromarket.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.pollos.micromarket.dto.request.ProductoRequestDTO;
import com.pollos.micromarket.dto.response.ProductoResponseDTO;
import com.pollos.micromarket.entity.Categoria;
import com.pollos.micromarket.entity.Producto;
import com.pollos.micromarket.exception.BusinessRuleException;
import com.pollos.micromarket.exception.DuplicateResourceException;
import com.pollos.micromarket.exception.ResourceNotFoundException;
import com.pollos.micromarket.mapper.ProductoMapper;
import com.pollos.micromarket.repository.CategoriaRepository;
import com.pollos.micromarket.repository.ProductoRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ProductoService {

    private final ProductoRepository productoRepository;
    private final CategoriaRepository categoriaRepository;
    private final ProductoMapper productoMapper;

    @Transactional
    public ProductoResponseDTO create(ProductoRequestDTO request) {
        validateBarcodeForCreate(request.getCodigoBarras());

        Categoria categoria = categoriaRepository.findById(request.getCategoriaId())
                .orElseThrow(() -> new ResourceNotFoundException("Categoría no encontrada con id: " + request.getCategoriaId()));

        if (request.getPrecioVenta().compareTo(request.getPrecioCompra()) < 0) {
            throw new BusinessRuleException("El precio de venta no puede ser menor al precio de compra");
        }

        Producto producto = new Producto();
        producto.setNombre(request.getNombre());
        producto.setDescripcion(request.getDescripcion());
        producto.setCodigoBarras(request.getCodigoBarras());
        producto.setPrecioCompra(request.getPrecioCompra());
        producto.setPrecioVenta(request.getPrecioVenta());
        producto.setStock(request.getStock());
        producto.setActivo(true);
        producto.setCategoria(categoria);

        return productoMapper.toResponse(productoRepository.save(producto));
    }

    @Transactional(readOnly = true)
    public List<ProductoResponseDTO> findAll(Boolean incluirInactivos) {
        List<Producto> productos = Boolean.TRUE.equals(incluirInactivos)
                ? productoRepository.findAll()
                : productoRepository.findByActivoTrue();

        return productoMapper.toResponseList(productos);
    }

    @Transactional(readOnly = true)
    public ProductoResponseDTO findById(Long id) {
        Producto producto = productoRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Producto no encontrado con id: " + id));

        return productoMapper.toResponse(producto);
    }

    @Transactional
    public ProductoResponseDTO update(Long id, ProductoRequestDTO request) {
        Producto producto = productoRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Producto no encontrado con id: " + id));

        if (productoRepository.existsByCodigoBarrasAndIdNot(request.getCodigoBarras(), id)) {
            throw new DuplicateResourceException("Ya existe un producto con ese código de barras");
        }

        Categoria categoria = categoriaRepository.findById(request.getCategoriaId())
                .orElseThrow(() -> new ResourceNotFoundException("Categoría no encontrada con id: " + request.getCategoriaId()));

        if (request.getPrecioVenta().compareTo(request.getPrecioCompra()) < 0) {
            throw new BusinessRuleException("El precio de venta no puede ser menor al precio de compra");
        }

        producto.setNombre(request.getNombre());
        producto.setDescripcion(request.getDescripcion());
        producto.setCodigoBarras(request.getCodigoBarras());
        producto.setPrecioCompra(request.getPrecioCompra());
        producto.setPrecioVenta(request.getPrecioVenta());
        producto.setStock(request.getStock());
        producto.setCategoria(categoria);

        Producto saved = productoRepository.save(producto);
        return findById(saved.getId());
    }

    @Transactional
    public ProductoResponseDTO toggleStatus(Long id, boolean activo) {
        Producto producto = productoRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Producto no encontrado con id: " + id));

        producto.setActivo(activo);
        return productoMapper.toResponse(productoRepository.save(producto));
    }

    @Transactional
    public void softDelete(Long id) {
        Producto producto = productoRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Producto no encontrado con id: " + id));
        producto.setActivo(false);
        productoRepository.save(producto);
    }

    private void validateBarcodeForCreate(String codigoBarras) {
        if (productoRepository.existsByCodigoBarras(codigoBarras)) {
            throw new DuplicateResourceException("Ya existe un producto con ese código de barras");
        }
    }
}
