package com.pollos.micromarket.enums;

public enum CargoEmpleado {
    ADMINISTRADOR,
    CAJERO,
    AUXILIAR
}
