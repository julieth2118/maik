package com.pollos.micromarket.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;

import com.pollos.micromarket.entity.Venta;

public interface VentaRepository extends JpaRepository<Venta, Long> {

    @Override
    @EntityGraph(attributePaths = {"empleado", "detalles", "detalles.producto"})
    Optional<Venta> findById(Long id);

    @EntityGraph(attributePaths = {"empleado", "detalles", "detalles.producto"})
    List<Venta> findAllByOrderByFechaVentaDesc();
}
