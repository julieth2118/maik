package com.pollos.micromarket.mapper;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

import com.pollos.micromarket.dto.response.EmpleadoResponseDTO;
import com.pollos.micromarket.entity.Empleado;

@Component
public class EmpleadoMapper {

    public EmpleadoResponseDTO toResponse(Empleado empleado) {
        EmpleadoResponseDTO dto = new EmpleadoResponseDTO();
        dto.setId(empleado.getId());
        dto.setCedula(empleado.getCedula());
        dto.setNombre(empleado.getNombre());
        dto.setCargo(empleado.getCargo());
        dto.setFechaIngreso(empleado.getFechaIngreso());
        dto.setSalario(empleado.getSalario());
        return dto;
    }

    public List<EmpleadoResponseDTO> toResponseList(List<Empleado> empleados) {
        return empleados.stream().map(this::toResponse).collect(Collectors.toList());
    }
}
