package com.pollos.micromarket.mapper;

import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

import com.pollos.micromarket.dto.response.CategoriaResponseDTO;
import com.pollos.micromarket.dto.response.ProductoSimpleResponseDTO;
import com.pollos.micromarket.entity.Categoria;
import com.pollos.micromarket.entity.Producto;

@Component
public class CategoriaMapper {

    public CategoriaResponseDTO toResponse(Categoria categoria) {
        CategoriaResponseDTO dto = new CategoriaResponseDTO();
        dto.setId(categoria.getId());
        dto.setNombre(categoria.getNombre());
        dto.setDescripcion(categoria.getDescripcion());
        dto.setProductos(categoria.getProductos().stream()
                .map(this::toProductoSimple)
                .collect(Collectors.toList()));
        return dto;
    }

    private ProductoSimpleResponseDTO toProductoSimple(Producto producto) {
        ProductoSimpleResponseDTO dto = new ProductoSimpleResponseDTO();
        dto.setId(producto.getId());
        dto.setNombre(producto.getNombre());
        dto.setCodigoBarras(producto.getCodigoBarras());
        dto.setPrecioVenta(producto.getPrecioVenta());
        dto.setStock(producto.getStock());
        dto.setActivo(producto.getActivo());
        return dto;
    }
}
