package com.pollos.micromarket.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.pollos.micromarket.dto.request.ProveedorRequestDTO;
import com.pollos.micromarket.dto.response.ProveedorResponseDTO;
import com.pollos.micromarket.entity.Proveedor;
import com.pollos.micromarket.exception.DuplicateResourceException;
import com.pollos.micromarket.exception.ResourceNotFoundException;
import com.pollos.micromarket.mapper.ProveedorMapper;
import com.pollos.micromarket.repository.ProveedorRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ProveedorService {

    private final ProveedorRepository proveedorRepository;
    private final ProveedorMapper proveedorMapper;

    @Transactional
    public ProveedorResponseDTO create(ProveedorRequestDTO request) {
        if (proveedorRepository.existsByNit(request.getNit())) {
            throw new DuplicateResourceException("Ya existe un proveedor con ese NIT");
        }

        Proveedor proveedor = new Proveedor();
        mapFields(request, proveedor);
        return proveedorMapper.toResponse(proveedorRepository.save(proveedor));
    }

    @Transactional(readOnly = true)
    public List<ProveedorResponseDTO> findAll() {
        return proveedorRepository.findAll().stream()
                .map(proveedorMapper::toResponse)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public ProveedorResponseDTO findById(Long id) {
        Proveedor proveedor = proveedorRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Proveedor no encontrado con id: " + id));

        return proveedorMapper.toResponse(proveedor);
    }

    @Transactional
    public ProveedorResponseDTO update(Long id, ProveedorRequestDTO request) {
        Proveedor proveedor = proveedorRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Proveedor no encontrado con id: " + id));

        if (proveedorRepository.existsByNitAndIdNot(request.getNit(), id)) {
            throw new DuplicateResourceException("Ya existe un proveedor con ese NIT");
        }

        mapFields(request, proveedor);
        return proveedorMapper.toResponse(proveedorRepository.save(proveedor));
    }

    public void delete(Long id) {
        Proveedor proveedor = proveedorRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Proveedor no encontrado con id: " + id));
        proveedorRepository.delete(proveedor);
    }

    private void mapFields(ProveedorRequestDTO request, Proveedor proveedor) {
        proveedor.setNombre(request.getNombre());
        proveedor.setNit(request.getNit());
        proveedor.setTelefono(request.getTelefono());
        proveedor.setCorreo(request.getCorreo());
        proveedor.setDireccion(request.getDireccion());
    }
}
