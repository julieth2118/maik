package com.pollos.micromarket.dto.response;

import lombok.Data;

@Data
public class ProveedorSimpleResponseDTO {
    private Long id;
    private String nombre;
    private String nit;
}
