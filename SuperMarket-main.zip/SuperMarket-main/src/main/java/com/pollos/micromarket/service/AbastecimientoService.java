package com.pollos.micromarket.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.pollos.micromarket.dto.request.EntradaAlmacenRequestDTO;
import com.pollos.micromarket.dto.response.ProductoResponseDTO;
import com.pollos.micromarket.entity.Producto;
import com.pollos.micromarket.entity.Proveedor;
import com.pollos.micromarket.exception.BusinessRuleException;
import com.pollos.micromarket.exception.ResourceNotFoundException;
import com.pollos.micromarket.mapper.ProductoMapper;
import com.pollos.micromarket.repository.ProductoRepository;
import com.pollos.micromarket.repository.ProveedorRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class AbastecimientoService {

    private final ProductoRepository productoRepository;
    private final ProveedorRepository proveedorRepository;
    private final ProductoMapper productoMapper;

    @Transactional
    public ProductoResponseDTO registrarEntrada(EntradaAlmacenRequestDTO request) {
        Producto producto = productoRepository.findById(request.getProductoId())
                .orElseThrow(() -> new ResourceNotFoundException("Producto no encontrado con id: " + request.getProductoId()));

        Proveedor proveedor = proveedorRepository.findById(request.getProveedorId())
                .orElseThrow(() -> new ResourceNotFoundException("Proveedor no encontrado con id: " + request.getProveedorId()));

        if (!Boolean.TRUE.equals(producto.getActivo())) {
            throw new BusinessRuleException("No se puede abastecer un producto inactivo");
        }

        producto.setStock(producto.getStock() + request.getCantidad());
        producto.getProveedores().add(proveedor);
        proveedor.getProductos().add(producto);

        Producto saved = productoRepository.save(producto);
        proveedorRepository.save(proveedor);

        return productoMapper.toResponse(saved);
    }
}
