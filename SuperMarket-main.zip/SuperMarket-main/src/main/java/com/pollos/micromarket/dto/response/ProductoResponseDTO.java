package com.pollos.micromarket.dto.response;

import java.math.BigDecimal;
import java.util.List;

import lombok.Data;

@Data
public class ProductoResponseDTO {
    private Long id;
    private String nombre;
    private String descripcion;
    private String codigoBarras;
    private BigDecimal precioCompra;
    private BigDecimal precioVenta;
    private Integer stock;
    private Boolean activo;
    private Long categoriaId;
    private String categoriaNombre;
    private List<ProveedorSimpleResponseDTO> proveedores;
}
