package com.pollos.micromarket.dto.response;

import java.util.List;

import lombok.Data;

@Data
public class ProveedorResponseDTO {
    private Long id;
    private String nombre;
    private String nit;
    private String telefono;
    private String correo;
    private String direccion;
    private List<ProductoSimpleResponseDTO> productos;
}
