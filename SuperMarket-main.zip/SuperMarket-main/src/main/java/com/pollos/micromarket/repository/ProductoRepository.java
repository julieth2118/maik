package com.pollos.micromarket.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;

import com.pollos.micromarket.entity.Producto;

public interface ProductoRepository extends JpaRepository<Producto, Long> {

    boolean existsByCodigoBarras(String codigoBarras);

    boolean existsByCodigoBarrasAndIdNot(String codigoBarras, Long id);

    @Override
    @EntityGraph(attributePaths = {"categoria", "proveedores"})
    List<Producto> findAll();

    @EntityGraph(attributePaths = {"categoria", "proveedores"})
    List<Producto> findByActivoTrue();

    @Override
    @EntityGraph(attributePaths = {"categoria", "proveedores"})
    Optional<Producto> findById(Long id);
}
