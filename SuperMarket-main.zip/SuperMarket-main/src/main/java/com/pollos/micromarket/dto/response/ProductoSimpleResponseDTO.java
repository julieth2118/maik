package com.pollos.micromarket.dto.response;

import java.math.BigDecimal;

import lombok.Data;

@Data
public class ProductoSimpleResponseDTO {
    private Long id;
    private String nombre;
    private String codigoBarras;
    private BigDecimal precioVenta;
    private Integer stock;
    private Boolean activo;
}
