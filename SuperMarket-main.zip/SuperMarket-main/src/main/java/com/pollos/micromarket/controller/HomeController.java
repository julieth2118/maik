package com.pollos.micromarket.controller;

import java.util.Map;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HomeController {

    @GetMapping("/")
    public Map<String, Object> home() {
        return Map.of(
                "aplicacion", "Micro-Market API",
                "estado", "activa",
                "version", "1.0",
                "basePath", "/api/v1"
        );
    }
}
