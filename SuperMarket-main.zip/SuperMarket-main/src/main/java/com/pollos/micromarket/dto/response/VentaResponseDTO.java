package com.pollos.micromarket.dto.response;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

import lombok.Data;

@Data
public class VentaResponseDTO {
    private Long id;
    private LocalDateTime fechaVenta;
    private Long empleadoId;
    private String empleadoNombre;
    private BigDecimal subtotal;
    private BigDecimal iva;
    private BigDecimal total;
    private List<DetalleVentaResponseDTO> detalles;
}
