package com.pollos.micromarket.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.pollos.micromarket.dto.request.EmpleadoRequestDTO;
import com.pollos.micromarket.dto.response.EmpleadoResponseDTO;
import com.pollos.micromarket.entity.Empleado;
import com.pollos.micromarket.enums.CargoEmpleado;
import com.pollos.micromarket.exception.BusinessRuleException;
import com.pollos.micromarket.exception.DuplicateResourceException;
import com.pollos.micromarket.exception.ResourceNotFoundException;
import com.pollos.micromarket.mapper.EmpleadoMapper;
import com.pollos.micromarket.repository.EmpleadoRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class EmpleadoService {

    private final EmpleadoRepository empleadoRepository;
    private final EmpleadoMapper empleadoMapper;

    @Transactional
    public EmpleadoResponseDTO create(EmpleadoRequestDTO request) {
        if (empleadoRepository.existsByCedula(request.getCedula())) {
            throw new DuplicateResourceException("Ya existe un empleado con esa cédula");
        }

        Empleado empleado = new Empleado();
        mapFields(request, empleado);

        return empleadoMapper.toResponse(empleadoRepository.save(empleado));
    }

    @Transactional(readOnly = true)
    public List<EmpleadoResponseDTO> findAll() {
        return empleadoMapper.toResponseList(empleadoRepository.findAll());
    }

    @Transactional(readOnly = true)
    public EmpleadoResponseDTO findById(Long id) {
        Empleado empleado = empleadoRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Empleado no encontrado con id: " + id));
        return empleadoMapper.toResponse(empleado);
    }

    @Transactional
    public EmpleadoResponseDTO update(Long id, EmpleadoRequestDTO request) {
        Empleado empleado = empleadoRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Empleado no encontrado con id: " + id));

        if (empleadoRepository.existsByCedulaAndIdNot(request.getCedula(), id)) {
            throw new DuplicateResourceException("Ya existe un empleado con esa cédula");
        }

        mapFields(request, empleado);
        return empleadoMapper.toResponse(empleadoRepository.save(empleado));
    }

    @Transactional
    public void delete(Long id) {
        Empleado empleado = empleadoRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Empleado no encontrado con id: " + id));
        empleadoRepository.delete(empleado);
    }

    @Transactional(readOnly = true)
    public List<EmpleadoResponseDTO> buscarPorCargoOCuandoIngreso(CargoEmpleado cargo, LocalDate fechaInicio, LocalDate fechaFin) {
        List<Empleado> empleados;

        if (cargo != null) {
            empleados = empleadoRepository.findByCargo(cargo);
        } else if (fechaInicio != null || fechaFin != null) {
            if (fechaInicio == null || fechaFin == null) {
                throw new BusinessRuleException("Para filtrar por fecha debes enviar fechaInicio y fechaFin");
            }
            if (fechaInicio.isAfter(fechaFin)) {
                throw new BusinessRuleException("La fechaInicio no puede ser mayor que la fechaFin");
            }
            empleados = empleadoRepository.findByFechaIngresoBetween(fechaInicio, fechaFin);
        } else {
            empleados = empleadoRepository.findAll();
        }

        return empleadoMapper.toResponseList(empleados);
    }

    private void mapFields(EmpleadoRequestDTO request, Empleado empleado) {
        empleado.setCedula(request.getCedula());
        empleado.setNombre(request.getNombre());
        empleado.setCargo(request.getCargo());
        empleado.setFechaIngreso(request.getFechaIngreso());
        empleado.setSalario(request.getSalario());
    }
}
