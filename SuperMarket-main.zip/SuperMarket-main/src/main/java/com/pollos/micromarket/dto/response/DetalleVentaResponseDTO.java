package com.pollos.micromarket.dto.response;

import java.math.BigDecimal;

import lombok.Data;

@Data
public class DetalleVentaResponseDTO {
    private Long id;
    private Long productoId;
    private String productoNombre;
    private Integer cantidad;
    private BigDecimal precioUnitario;
    private BigDecimal subtotalLinea;
}
