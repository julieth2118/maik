package Main;

import java.util.ArrayList;
import java.util.Scanner;
import model.Bicicleta;
import repository.BicicletaRepository;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        BicicletaRepository bicicletaRepository = new BicicletaRepository();
        int opcion;

        do {
            System.out.println("\n menu del inventario : \n");
            System.out.println("1. Insertar un nuevo tipo  de bicicleta");
            System.out.println("2. Lista de todas las bicicletas");
            System.out.println("3. Vender la bicicleta");
            System.out.println("4. Agregar stock a la bicicleta");
            System.out.println("5. Buscar la bicicleta por ID");
            System.out.println("6. Actualizacion de la bicicleta");
            System.out.println("7. Eliminar la bicicleta");
            System.out.println("0. Salir");
            System.out.print("Seleccione una opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine(); 

            switch (opcion) {
                case 1:
                    System.out.print("Ingrese el nombre de la bicicleta: ");
                    String nombre = scanner.nextLine();
                    System.out.print("Ingrese el precio de la bicicleta: ");
                    Long precio = scanner.nextLong();
                    System.out.print("Ingrese la cantidad inicial: ");
                    Long cantidad = scanner.nextLong();

                    Bicicleta nuevaBici = new Bicicleta(nombre, precio, cantidad);
                    bicicletaRepository.insertarBicicleta(nuevaBici);
                    break;

                case 2:
                    System.out.println("\n\n LISTA DE TODAS LAS BICICLETAS: \n");
                    ArrayList<Bicicleta> bicicletas = bicicletaRepository.listarBicicletas();
                    for (Bicicleta b : bicicletas) {
                        System.out.println("ID: " + b.getId() + " | Nombre: " + b.getNombre() +
                                           " | Precio: " + b.getPrecio() + " | Cantidad: " + b.getCantidad());
                    }
                    break;

                case 3:
                    System.out.println("\n\n ver las bicicletas disponibles para verder: \n");
                    ArrayList<Bicicleta> disponibles = bicicletaRepository.listarBicicletasDisponibles();
                    for (Bicicleta b : disponibles) {
                        System.out.println("ID: " + b.getId() + " | " + b.getNombre() + 
                                           " | Precio: " + b.getPrecio() + 
                                           " | Cantidad: " + b.getCantidad());
                    }
                    System.out.print("Ingrese el ID de la bicicleta a vender: ");
                    Long idVender = scanner.nextLong();
                    bicicletaRepository.venderBicicleta(idVender);
                    break;

                case 4:
                System.out.println("\n lista de todas las bicicletas: \n");
                    ArrayList<Bicicleta> bicicletasLista = bicicletaRepository.listarBicicletas();
                    for (Bicicleta b : bicicletasLista) {
                        System.out.println("ID: " + b.getId() + " | Nombre: " + b.getNombre() +
                                           " | Precio: " + b.getPrecio() + " | Cantidad: " + b.getCantidad());
                    }
                    System.out.print("Ingrese el ID de la bicicleta a la que desea agregar stock: ");
                    Long idAgregar = scanner.nextLong();
                    System.out.print("Ingrese la cantidad a agregar: ");
                    Long cantidadAgregar = scanner.nextLong();
                    bicicletaRepository.agregarStock(idAgregar, cantidadAgregar);
                    break;

                case 5:
                    System.out.print("Ingrese el ID de la bicicleta a buscar: ");
                    Long idBuscar = scanner.nextLong();
                    Bicicleta biciBuscada = bicicletaRepository.obtenerBicicletaPorId(idBuscar);
                    if (biciBuscada != null) {
                        System.out.println("ID: " + biciBuscada.getId() + " | Nombre: " + biciBuscada.getNombre() +
                                           " | Precio: " + biciBuscada.getPrecio());
                    } else {
                        System.out.println("No se encontró una bicicleta con ese ID.");
                    }
                    break;

                case 6:
                    System.out.print("Ingrese el ID de la bicicleta a actualizar: ");
                    Long idActualizar = scanner.nextLong();
                    scanner.nextLine();
                    System.out.print("Nuevo nombre: ");
                    String nuevoNombre = scanner.nextLine();
                    System.out.print("Nuevo precio: ");
                    Long nuevoPrecio = scanner.nextLong();
                    System.out.print("Nueva cantidad: ");
                    Long nuevaCantidad = scanner.nextLong();
                    bicicletaRepository.actualizarBicicleta(idActualizar, nuevoNombre, nuevoPrecio, nuevaCantidad);
                    break;

                case 7:
                    System.out.print("Ingrese el ID de la bicicleta a eliminar: ");
                    Long idEliminar = scanner.nextLong();
                    bicicletaRepository.eliminarBicicleta(idEliminar);
                    break;

                case 0:
                    System.out.println("hasta luego, un gusto atenderlo, que vuelva pronto ");
                    break;

                default:
                    System.out.println("Opción inválida. Intente de nuevo.");
            }
        } while (opcion != 0);

        scanner.close();
    }
}
