package model;

public class Bicicleta {
    private Long id;
    private String nombre;
    private Long precio;
    private Long cantidad;

    public Bicicleta(Long id, String nombre, Long precio, Long cantidad){
        this.nombre= nombre;
        this.precio=precio;
        this.cantidad= cantidad;
    }

    public Bicicleta(String nombre, Long precio, Long cantidad){
        this.nombre=nombre;
        this.precio=precio;
        this.cantidad= cantidad;
    }

    public Long getId() {return id;}
    public void setId(Long id){this.id = id;}
    public String getNombre() {return nombre;}
    public void setNombre(String nombre){this.nombre=nombre;}
    public Long getPrecio() {return precio;}
    public void setPrecio(Long precio){this.precio=precio;}
    public Long getCantidad() {return cantidad;}
    public void setCantidad(Long cantidad){this.cantidad=cantidad;}
    
}
