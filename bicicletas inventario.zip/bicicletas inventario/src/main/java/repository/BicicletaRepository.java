package repository;

import java.sql.Connection;
import java.sql.PreparedStatement;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import db.Conexion;
import model.Bicicleta;

public class BicicletaRepository {
    
    public void insertarBicicleta(Bicicleta bicicleta) {
        String sql = "INSERT INTO Bicicleta (NOMBRE, PRECIO, CANTIDAD) VALUES (?, ?, ?)";

        try (Connection connection = Conexion.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {

            preparedStatement.setString(1, bicicleta.getNombre());
            preparedStatement.setLong(2, bicicleta.getPrecio());
            preparedStatement.setLong(3, bicicleta.getCantidad());

            preparedStatement.executeUpdate();

            System.out.println("Bicicleta insertado correctamente");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public ArrayList<Bicicleta> listarBicicletas() {
        ArrayList<Bicicleta> listaBicicletas = new ArrayList<>();
        String sql = "SELECT * FROM Bicicleta";

        try (Connection connection = Conexion.getConnection();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(sql)) {
                

            while (resultSet.next()) {
                Bicicleta bicicleta = new Bicicleta(null,null,null);
                bicicleta.setId(resultSet.getLong("ID"));
                bicicleta.setNombre(resultSet.getString("NOMBRE"));
                bicicleta.setPrecio(resultSet.getLong("PRECIO"));
                bicicleta.setCantidad(resultSet.getLong("CANTIDAD"));

                listaBicicletas.add(bicicleta);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return listaBicicletas;
    }    

    public void actualizarBicicleta(Long id, String nuevoNombre, Long nuevoPrecio, Long nuevaCantidad) {
        String sql = "UPDATE Bicicleta SET NOMBRE = ?, PRECIO = ?, CANTIDAD = ? WHERE ID = ?";
        try (Connection connection = Conexion.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {

            preparedStatement.setLong(3, nuevaCantidad);
            preparedStatement.setString(1, nuevoNombre);
            preparedStatement.setLong(2, nuevoPrecio);
            preparedStatement.setLong(4, id);

            int filas = preparedStatement.executeUpdate();
            if (filas > 0) {
                System.out.println("Bicicleta actualizado correctamente");
            } else {
                System.out.println("No se encontró un Bicicleta con ese ID");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void eliminarBicicleta(Long id) {
        String sql = "DELETE FROM Bicicleta WHERE ID = ?";
        try (Connection connection = Conexion.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {

            preparedStatement.setLong(1, id);

            int filas = preparedStatement.executeUpdate();
            if (filas > 0) {
                System.out.println("Se eliminó la Bicicleta");
            } else {
                System.out.println("No se encontró la Bicicleta");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public Bicicleta obtenerBicicletaPorId(Long id) {
    Bicicleta Bicicleta = null;
    String sql = "SELECT * FROM Bicicleta WHERE ID = ?";

    try (Connection connection = Conexion.getConnection();
         PreparedStatement preparedstatement = connection.prepareStatement(sql)) {

        preparedstatement.setLong(1, id);
        ResultSet resultSet = preparedstatement.executeQuery();

        if (resultSet.next()) {
            Bicicleta = new Bicicleta(null,null,null, null);
            Bicicleta.setId(resultSet.getLong("ID"));
            Bicicleta.setNombre(resultSet.getString("NOMBRE"));
            Bicicleta.setPrecio(resultSet.getLong("PRECIO"));
            Bicicleta.setPrecio(resultSet.getLong("CANTIDAD"));
        }

        resultSet.close();
    } catch (Exception e) {
        e.printStackTrace();
    }

    return Bicicleta;
    }

    public Bicicleta obtenerBicicletaPorNombre(String nombre) {
    Bicicleta Bicicleta = null;
    String sql = "SELECT * FROM Bicicleta WHERE NOMBRE = ?";

    try (Connection connection = Conexion.getConnection();
         PreparedStatement preparedstatement = connection.prepareStatement(sql)) {

        preparedstatement.setString(1, nombre);
        ResultSet resultSet = preparedstatement.executeQuery();

        if (resultSet.next()) {
            Bicicleta = new Bicicleta(null,null,null, null);
            Bicicleta.setId(resultSet.getLong("ID"));
            Bicicleta.setNombre(resultSet.getString("NOMBRE"));
            Bicicleta.setPrecio(resultSet.getLong("PRECIO"));
            Bicicleta.setPrecio(resultSet.getLong("CANTIDAD"));
        }

        resultSet.close();
    } catch (Exception e) {
        e.printStackTrace();
    }

    return Bicicleta;
    }

    public boolean venderBicicleta(Long id) {
    String sqlConsultar = "SELECT CANTIDAD FROM Bicicleta WHERE ID = ?";
    String sqlActualizar = "UPDATE Bicicleta SET CANTIDAD = CANTIDAD - 1 WHERE ID = ?";

    try (Connection connection = Conexion.getConnection();
         PreparedStatement preparedStatementConsultar = connection.prepareStatement(sqlConsultar)) {

        // Consultar cantidad actual
        preparedStatementConsultar.setLong(1, id);
        ResultSet resultSet = preparedStatementConsultar.executeQuery();

        if (resultSet.next()) {
            long cantidad = resultSet.getLong("CANTIDAD");

            if (cantidad > 0) {
                try (PreparedStatement preparedStatementActualizar = connection.prepareStatement(sqlActualizar)) {
                    preparedStatementActualizar.setLong(1, id);
                    preparedStatementActualizar.executeUpdate();
                    System.out.println("Venta realizada exitosamente.");
                    return true;
                }
            } else {
                System.out.println("No hay unidades disponibles para esta bicicleta.");
                return false;
            }
        } else {
            System.out.println("No se encontró una bicicleta con ese ID.");
        }

        resultSet.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public void agregarStock(Long id, Long cantidadAgregar) {
    String sql = "UPDATE Bicicleta SET CANTIDAD = CANTIDAD + ? WHERE ID = ?";

    try (Connection connection = Conexion.getConnection();
         PreparedStatement preparedStatement = connection.prepareStatement(sql)) {

        preparedStatement.setLong(1, cantidadAgregar);
        preparedStatement.setLong(2, id);

        int filas = preparedStatement.executeUpdate();

        if (filas > 0) {
            System.out.println("Stock agregado correctamente.");
        } else {
            System.out.println("No se encontró una bicicleta con ese ID.");
        }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public ArrayList<Bicicleta> listarBicicletasDisponibles() {
        ArrayList<Bicicleta> listaBicicletas = new ArrayList<>();
        String sql = "SELECT * FROM Bicicleta WHERE CANTIDAD > 0";

        try (Connection connection = Conexion.getConnection();
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(sql)) {

            while (resultSet.next()) {
                Bicicleta bicicleta = new Bicicleta(null,null,null);
                bicicleta.setId(resultSet.getLong("ID"));
                bicicleta.setNombre(resultSet.getString("NOMBRE"));
                bicicleta.setPrecio(resultSet.getLong("PRECIO"));
                bicicleta.setCantidad(resultSet.getLong("CANTIDAD"));
                listaBicicletas.add(bicicleta);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return listaBicicletas;
}


}


